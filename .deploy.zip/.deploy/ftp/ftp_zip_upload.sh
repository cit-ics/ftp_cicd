#!/bin/bash

WORKSPACE_ROOT=$(pwd)
CONFIG_FILE="$WORKSPACE_ROOT/.deploy/config.json"

# FTP server credentials and details
# Load FTP details from config.json using jq
FTP_HOST=$(jq -r '.ftp.host' "$CONFIG_FILE")
FTP_USER=$(jq -r '.ftp.user' "$CONFIG_FILE")
FTP_PASS=$(jq -r '.ftp.pass' "$CONFIG_FILE")
FTP_DIR=$(jq -r '.ftp.dir' "$CONFIG_FILE")

# File to upload
FILE_TO_UPLOAD="$WORKSPACE_ROOT/app.zip"

ZIP_FILE="app.zip"
IGNORE_FILE="$WORKSPACE_ROOT/.zip_ignore"

# === Creating app.zip with .zip_ignore ===
echo "🔄 Step 1: Creating $ZIP_FILE (ignoring patterns from $IGNORE_FILE)..."

# Create a temporary file list for exclusion
EXCLUDES=()
if [ -f "$IGNORE_FILE" ]; then
    while read -r line || [[ -n "$line" ]]; do
        [[ -z "$line" || "$line" == \#* ]] && continue  # skip empty/comments
        EXCLUDES+=("-x" "$line")
    done < "$IGNORE_FILE"
fi

# Create the zip archive
zip -r "$ZIP_FILE" . "${EXCLUDES[@]}"
echo "✅ Zip file created: $ZIP_FILE"
echo

if [ ! -f "$FILE_TO_UPLOAD" ]; then
    echo "❌ $FILE_TO_UPLOAD not found"
    exit 1
fi

# Upload using curl
curl -T "$FILE_TO_UPLOAD" "ftp://$FTP_HOST$FTP_TARGET_DIR/" --user "$FTP_USER:$FTP_PASS"

# Check if the upload was successful
if [ $? -eq 0 ]; then
  echo "Upload successful."
else
  echo "Upload failed."
fi
