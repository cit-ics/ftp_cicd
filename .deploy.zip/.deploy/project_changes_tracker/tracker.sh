#!/bin/bash

# sudo apt install inotify-tools

WORKSPACE_ROOT=$(pwd)
TRACKING_DIR="$WORKSPACE_ROOT/.deploy/project_changes_tracker/.modify_tracking"
MODIFIED_FILE="$TRACKING_DIR/modified.json"
IGNORE_FILE="$WORKSPACE_ROOT/.modify_track_ignore"
GITIGNORE_PATH="$TRACKING_DIR/.gitignore"

mkdir -p "$TRACKING_DIR"
[[ ! -f "$MODIFIED_FILE" ]] && echo "[]" > "$MODIFIED_FILE"
[[ ! -f "$GITIGNORE_PATH" ]] && echo "*" > "$GITIGNORE_PATH"

# Load ignore list
declare -a IGNORE_LIST
if [[ -f "$IGNORE_FILE" ]]; then
  mapfile -t IGNORE_LIST < "$IGNORE_FILE"
fi

# Helper function to check if path is ignored
is_ignored() {
  local path="$1"
  for ignore in "${IGNORE_LIST[@]}"; do
    if [[ "$path" == *"$ignore"* ]]; then
      return 0
    fi
  done
  return 1
}

# Update JSON array with new file
update_modified_json() {
  local file="$1"
  rel_path="/${file#$WORKSPACE_ROOT/}"
  if [[ "$rel_path" == /.modify_tracking* ]] || is_ignored "$rel_path"; then
    return
  fi

  # Add only if not already in array
  tmp=$(mktemp)
  jq --arg path "$rel_path" 'if index($path) then . else . + [$path] end' "$MODIFIED_FILE" > "$tmp" && mv "$tmp" "$MODIFIED_FILE"
}

# Remove from modified.json if deleted
remove_from_modified_json() {
  local file="$1"
  rel_path="/${file#$WORKSPACE_ROOT/}"
  tmp=$(mktemp)
  jq --arg path "$rel_path" 'del(.[] | select(. == $path))' "$MODIFIED_FILE" > "$tmp" && mv "$tmp" "$MODIFIED_FILE"
}

echo "Watching for file changes in: $WORKSPACE_ROOT"
inotifywait -mrq --format '%e %w%f' -e modify,create,delete "$WORKSPACE_ROOT" | while read -r event fullpath; do
  case "$event" in
    *CREATE*|*MODIFY*)
      update_modified_json "$fullpath"
      ;;
    *DELETE*)
      remove_from_modified_json "$fullpath"
      ;;
  esac
done
