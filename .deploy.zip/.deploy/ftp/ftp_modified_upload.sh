#!/bin/bash

WORKSPACE_ROOT=$(pwd)
CONFIG_FILE="$WORKSPACE_ROOT/.deploy/config.json"

# FTP server credentials and details
# Load FTP details from config.json using jq
FTP_HOST=$(jq -r '.ftp.host' "$CONFIG_FILE")
FTP_USER=$(jq -r '.ftp.user' "$CONFIG_FILE")
FTP_PASS=$(jq -r '.ftp.pass' "$CONFIG_FILE")
FTP_DIR=$(jq -r '.ftp.dir' "$CONFIG_FILE")

# === Paths ===
TRACKING_DIR="$WORKSPACE_ROOT/.deploy/project_changes_tracker/.modify_tracking"
MODIFIED_FILE="$TRACKING_DIR/modified.json"

# === Check for modified.json existence ===
if [ ! -f "$MODIFIED_FILE" ]; then
  echo "❌ Modified file list not found: $MODIFIED_FILE"
  exit 1
fi

# === Read and upload files ===
FILES=$(jq -r '.[]' "$MODIFIED_FILE")

for FILE in $FILES; do
  LOCAL_PATH="$WORKSPACE_ROOT/$FILE"

  if [ -f "$LOCAL_PATH" ]; then
    echo ""
    echo "⬆️ Uploading: $FILE"

    # Escape paths for FTP
    ENCODED_PATH=$(echo "$FTP_TARGET_DIR/$FILE" | sed 's/ /%20/g')

    # Upload with curl
    curl -s --ftp-create-dirs -T "$LOCAL_PATH" "ftp://$FTP_HOST$ENCODED_PATH" --user "$FTP_USER:$FTP_PASS"

    if [ $? -eq 0 ]; then
      echo "✅ Upload successful: $FILE"
    else
      echo "❌ Upload failed: $FILE"
    fi
  else
    echo "⚠️ File not found locally: $LOCAL_PATH"
  fi
done

# === Clear modified.json ===
echo "[]" > "$MODIFIED_FILE"
echo ""
echo "🧹 Cleared modified.json after upload."
