#!/bin/bash


WORKSPACE_ROOT=$(pwd)
CONFIG_FILE="$WORKSPACE_ROOT/.deploy/config.json"

# Config
VPS_USER=$(jq -r '.vps.user' "$CONFIG_FILE")
VPS_IP=$(jq -r '.vps.ip' "$CONFIG_FILE")
VPS_DEST=$(jq -r '.vps.dir' "$CONFIG_FILE")
SSH_KEY="$HOME/$(jq -r '.vps.ssh' "$CONFIG_FILE" | sed 's|^/||')"

IGNORE_FILE="$WORKSPACE_ROOT/.deploy/vps/.zip_ignore"
TRACKING_DIR="$WORKSPACE_ROOT/.deploy/project_changes_tracker/.modify_tracking"
TRACKING_FILE="$TRACKING_DIR/modified.json"

# Check file
if [ ! -f "$TRACKING_FILE" ]; then
    echo "❌ $TRACKING_FILE not found"
    exit 1
fi

# Create temp file list
TMP_LIST=$(mktemp)
jq -r '.[]' "$TRACKING_FILE" > "$TMP_LIST"

echo "📦 Uploading modified files via rsync..."
rsync -avz --files-from="$TMP_LIST" ./ -e "ssh -i $SSH_KEY" "$VPS_USER@$VPS_IP:$VPS_DEST"

rm "$TMP_LIST"
echo "✅ Done: Modified files uploaded using rsync"

# Clear the modified.json file with an empty array
echo "[]" > "$TRACKING_FILE"
echo "✅ Cleared modified.json after upload."



# === SSH into VPS, extract and run ===
echo "📡 Connecting to VPS and setting up project..."

ssh -i "$SSH_KEY" "$VPS_USER@$VPS_IP" bash <<EOF
set -e
echo "📂 Step 4: Changing directory to $VPS_DEST..."
cd "$VPS_DEST"

# Inside ssh block on VPS
echo "🚀 Running project update scripts..."
if [ -f after_deploy_commands.sh ]; then
    chmod +x after_deploy_commands.sh
    ./after_deploy_commands.sh && echo "✅ after_deploy_commands.sh executed successfully." || echo "❌ after_deploy_commands.sh ran but returned error."
else
    echo "⚠️ after_deploy_commands.sh not found, skipping custom setup."
fi

EOF