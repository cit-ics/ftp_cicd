#!/bin/bash

set -e

echo "🚀 Starting deployment activation..."

# === Step 0: Config & Path Setup ===
WORKSPACE_ROOT=$(pwd)
CONFIG_FILE="$WORKSPACE_ROOT/.deploy/config.json"

if [[ ! -f "$CONFIG_FILE" ]]; then
  echo "❌ Config file not found: $CONFIG_FILE"
  exit 1
fi

echo "🔍 Validating config.json..."

VPS_IP=$(jq -r '.vps.ip' "$CONFIG_FILE")
VPS_USER=$(jq -r '.vps.user' "$CONFIG_FILE")
VPS_EMAIL=$(jq -r '.vps.email' "$CONFIG_FILE")
SSH_PATH_REL=$(jq -r '.vps.ssh' "$CONFIG_FILE" | sed 's|^/||')
SSH_KEY="$HOME/$SSH_PATH_REL"

# Check for required fields
if [[ -z "$VPS_IP" || -z "$VPS_USER" || -z "$VPS_EMAIL" ]]; then
  echo "❌ Missing VPS IP, user, or email in config.json"
  exit 1
fi


# === Step 0.5: Create default ignore files ===
echo "📁 Creating default .modify_track_ignore and .zip_ignore..."

IGNORE_FILE="$WORKSPACE_ROOT/.modify_track_ignore"
ZIP_IGNORE_FILE="$WORKSPACE_ROOT/.zip_ignore"
DEPLOY_COMMANDS="$WORKSPACE_ROOT/after_deploy_commands.sh"

[[ ! -f "$IGNORE_FILE" ]] && echo "Created $IGNORE_FILE"
[[ ! -f "$ZIP_IGNORE_FILE" ]] && echo "Created $ZIP_IGNORE_FILE"

touch "$IGNORE_FILE"
touch "$ZIP_IGNORE_FILE"

add_ignore_entry() {
  local file="$1"
  shift
  for entry in "$@"; do
    if ! grep -qxF "$entry" "$file" 2>/dev/null; then
      echo "$entry" >> "$file"
      echo "➕ Added '$entry' to $file"
    fi
  done
}

add_ignore_entry "$IGNORE_FILE" "/storage" "/vendor" "/node_modules" "/bootstrap/cache" "/.deploy"
add_ignore_entry "$ZIP_IGNORE_FILE" ".deploy/" ".git*" "node_modules/*" ".env"

cat > "$DEPLOY_COMMANDS" <<'EOF'
#!/bin/bash

echo "🔧 Setting up the environment..."

echo "🔢 Incrementing APP_VERSION in .env..."

if [ -f .env ]; then
    # Extract current version
    current_version=$(grep "^APP_VERSION=" .env | cut -d "\"" -f2)

    if [ -z "$current_version" ]; then
        # APP_VERSION not found, set default
        echo "APP_VERSION=\"1.0\"" >> .env
        echo "✅ APP_VERSION not found. Set to default: 1.0"
    elif [[ $current_version =~ ^([0-9]+)\.([0-9]+)$ ]]; then
        major=${BASH_REMATCH[1]}
        minor=${BASH_REMATCH[2]}
        new_minor=$((minor + 1))
        new_version="${major}.${new_minor}"

        # Replace version in .env
        sed -i "s/^APP_VERSION=\"${current_version}\"/APP_VERSION=\"${new_version}\"/" .env

        echo "✅ APP_VERSION updated: $current_version → $new_version"
    else
        echo "⚠️ Could not parse APP_VERSION format: '\''$current_version'\''"
    fi
else
    echo "❌ .env file not found."
fi

if [ -f artisan ]; then
    echo "🔁 Clear site cache..."
    php artisan o:clear
fi

echo "✅ Setup complete."
'

echo "✅ Ignore files updated."
EOF

chmod +x "$DEPLOY_COMMANDS"


# === Step 0.6: Setup SSH Keys ===

echo "🔧 Making deployment scripts executable..."

chmod +x \
  .deploy/ftp/ftp_modified_upload.sh \
  .deploy/ftp/ftp_zip_upload.sh \
  .deploy/project_changes_tracker/tracker.sh \
  .deploy/vps/deploy_modified_into_vps.sh \
  .deploy/vps/deploy_zip_into_vps.sh

echo "✅ All deployment scripts are now executable."


# === Step 0.7: Setup SSH Keys ===

PACKAGE_JSON="$WORKSPACE_ROOT/package.json"

if [[ ! -f "$PACKAGE_JSON" ]]; then
    sudo npm init -y
    echo "created package.json not found in project root."
    exit 1
fi

echo "🛠 Updating scripts section in package.json..."

# Use jq to update or create the scripts section
TMP_PKG=$(mktemp)

jq '
  .type = "module" |
  .scripts += {
    "track": "sh .deploy/project_changes_tracker/tracker.sh",
    "vps_modified_deploy": "sh .deploy/vps/deploy_modified_into_vps.sh",
    "vps_zip_deploy": "sh .deploy/vps/deploy_zip_into_vps.sh",
    "ftp_zip_deploy": "sh .deploy/ftp/ftp_zip_upload.sh",
    "ftp_modified_deploy": "sh .deploy/ftp/ftp_modified_upload.sh"
  }
' "$PACKAGE_JSON" > "$TMP_PKG" && mv "$TMP_PKG" "$PACKAGE_JSON"

echo "✅ package.json scripts updated."


# === Step 1: Setup SSH Keys ===
echo "🔑 Checking for SSH key at $SSH_KEY..."

if [[ ! -f "$SSH_KEY" ]]; then
  echo "🛠 Generating SSH key..."
  ssh-keygen -t rsa -b 4096 -C "$VPS_EMAIL" -f "$SSH_KEY" -N ""
else
  echo "✅ SSH key exists."
fi

# Add key to VPS
echo "🔐 Adding SSH key to VPS $VPS_USER@$VPS_IP..."
ssh-copy-id -i "$SSH_KEY" "$VPS_USER@$VPS_IP"

# === Step 2: Install jq and inotify-tools ===
echo "📦 Installing jq and inotify-tools..."
sudo apt update
sudo apt install -y jq inotify-tools

# === Step 3: Install chokidar-cli ===
echo "📦 Installing chokidar-cli globally via npm..."

if ! command -v chokidar &> /dev/null; then
  if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed. Please install Node.js and npm first."
    exit 1
  fi
  sudo npm install -g chokidar-cli
else
  echo "✅ chokidar-cli is already installed."
fi

echo "🎉 Deployment environment setup complete."
